def main(input_files=None, output_file=None, params=None):
    if output_file is not None:
        with open(output_file, "w") as oo:
            print(params, file=oo)
            print(input_files, file=oo)
    return "I am a yummy test dummy!"


if __name__ == "__main__":
    main()
